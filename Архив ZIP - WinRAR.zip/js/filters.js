function scrollDown() { //scrolls down filter on click
    var myDiv = document.getElementById("filters");
    myDiv.scrollTop = myDiv.scrollHeight;
}